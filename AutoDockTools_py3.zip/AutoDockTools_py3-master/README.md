# AutoDockTools_py3
Python3 translation of AutoDockTools

**Install**

*Linux*

`python -m pip install git+https://github.com/Valdes-Tresanco-MS/AutoDockTools_py3`

*Windows*

`python.exe -m pip install git+https://github.com/Valdes-Tresanco-MS/AutoDockTools_py3`

# This version is under test.
